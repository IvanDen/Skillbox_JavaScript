$(document).ready(function()
{
    if (localStorage.getItem('edit-text'))
    {
        $('.js-text-p').html(localStorage.getItem('edit-text'));
    }

    $('.js-edit').on('click', function ()
    {
        var editPElem = $('.js-text-p');
        editPElem.attr('contentEditable', true);
        var editText;


        $(this).attr('disabled', true);
        if($(this).attr('disabled', true))
        {
            $('.js-save, .js-cancel').removeAttr('disabled');
        }
        if (editText === undefined)
        {
            localStorage.setItem('edit-text', $('.js-text-p').html());
            editText = localStorage.getItem('edit-text');
        }

        $('.js-save').on('click', function ()
        {
            $('.js-edit').removeAttr('disabled');
            $('.js-save, .js-cancel').prop('disabled', true);
            localStorage.setItem('edit-text', $('.js-text-p').html());
            editPElem.attr('contentEditable', false);
        });
        $('.js-cancel').on('click', function ()
        {
            $('.js-edit').removeAttr('disabled');
            $('.js-save, .js-cancel').prop('disabled', true);
            editText = localStorage.getItem('edit-text');
            console.log('getItem: ' + editText);
            $('.js-text-p').html(editText);
            editPElem.attr('contentEditable', false);
        })
    })
});
