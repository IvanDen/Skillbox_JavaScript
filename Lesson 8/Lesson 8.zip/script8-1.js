var partScript = prompt('Enter working java script code');

// пример var a = true; if (a) { 1+1 } else { 1+2 }

console.log(partScript);

function runsTheCode()
{
    'use string';
    if (eval(partScript) !==  undefined)
    {
        console.log(eval(partScript));

    }
    else
    {
        console.error('Your code is not valid');
    }
}
// runsTheCode();
try
{
    runsTheCode();
}
catch
{
    alert('Your code is not valid');
}





