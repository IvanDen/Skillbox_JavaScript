startGame();
triesFun();

